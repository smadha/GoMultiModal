import re
str = '11 Object[0] = {Type: "Face" |--Region: Left=204.0, Top=59.7, Right=312.2, Bottom=167.8 |--Marker { |--LeftEye: X=285.3, Y=97.0  |--LeftMouthCorner: X=272.1, Y=150.5  |--NoseTip: X=253.6, Y=121.8  |--RightEye: X=236.4, Y=90.3  |--RightMouthCorner: X=235.5, Y=150.5 }|--Attribute { |--Gender =   |--Id = 0  |--Pitch = 0  |--Roll = 0  |--Yaw = 0 }|--Rating { |--Age = 45.0  |--AgeDeviation = 10.0  |--Angry = 0.0  |--Female = 0.0  |--Happy = 0.0  |--LeftEyeClosed = 100.0  |--Male = 100.0  |--MouthOpen = 8.0  |--RightEyeClosed = 100.0  |--Sad = 0.0  |--Score = 67.6  |--Surprised = 0.0  |--Uptime = 0.4 }|--Part { |--LeftEye | Type: "LeftEye.Front"  | |--Region: Left=268.1, Top=79.8, Right=302.6, Bottom=114.3  | |--Marker { |  |--LeftEye: X=285.3, Y=97.0 } | |--Rating { |  |--Score = 42.0 } | |--Mouth | Type: "Mouth.Front"  | |--Region: Left=229.4, Top=129.2, Right=278.1, Bottom=171.8  | |--Marker { |  |--LeftMouthCorner: X=272.1, Y=150.5  |  |--RightMouthCorner: X=235.5, Y=150.5 } | |--Rating { |  |--Score = 72.0 } | |--Nose | Type: "Nose.Front"  | |--Region: Left=232.6, Top=95.5, Right=274.6, Bottom=137.5  | |--Marker { |  |--NoseTip: X=253.6, Y=121.8 } | |--Rating { |  |--Score = 72.0 } | |--RightEye Type: "RightEye.Front"  |--Region: Left=220.1, Top=74.1, Right=252.6, Bottom=106.5  |--Marker {  |--RightEye: X=236.4, Y=90.3 } |--Rating {  |--Score = 61.0 }}}'
m = re.search('Rating {(( \|--([\w]+) = ([\d.]+) )+)}',str)
interesting_part = m.groups()[0]
tokens = interesting_part.split('|--')
for token in tokens:
    elements = token.split("=")
    if(len(elements)==2):
        print elements[0].strip();
        print elements[1].strip();